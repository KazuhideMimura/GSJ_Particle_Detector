import os
import time
from datetime import datetime
from hashlib import md5
from pathlib import Path

from ..helper.threading import SubprocessWorker, SubprocessWorkerThread


class DetectionThread(SubprocessWorkerThread):
    def __init__(self, exec: str, startfile: str, **kwargs):
        super().__init__(
            worker=DetectionWorker(exec=exec, startfile=startfile, **kwargs),
        )


class DetectionWorker(SubprocessWorker):
    startfile: Path = None

    file_mtime: datetime = None
    file_hash: str = None

    def __init__(self, exec: str, startfile: str, waiting_interval: float = 0.1, **kwargs):
        super().__init__(exec=exec, waiting_interval=waiting_interval, **kwargs)

        self.startfile = Path(startfile)
        self.wait_interval = max(waiting_interval, 0.05)

    def _hash(self, filename: os.PathLike) -> str:
        if not Path(filename).exists():
            return None

        with open(filename, "rb") as f:
            return md5(f.read()).hexdigest()

    def _timestamp(self, filename: os.PathLike) -> datetime:
        if not Path(filename).exists():
            return None

        return Path(filename).stat().st_mtime

    def is_updated(self) -> bool:
        if not self.startfile.exists():
            return False

        if self._timestamp(self.startfile) != self.file_mtime:
            return True

        if self._hash(self.startfile) != self.file_hash:
            return True

        return False

    def reset_state(self):
        self.file_mtime = self._timestamp(self.startfile)
        self.file_hash = self._hash(self.startfile)

    def __call__(self):
        self.reset_state()

        self.workerStart.emit()
        self.debug.emit("Detection loop start.")

        while True:
            if self.is_updated():
                self.info.emit("Modified start file.")
                self.exec_subprocess()
                self.reset_state()
            else:
                self.waiting.emit()
                time.sleep(self.wait_interval)

            with self.lock_obj:
                if self.stop_flag:
                    self.info.emit("Break detection worker.")
                    break

        self.debug.emit("Detection loop finished.")
        self.workerEnd.emit()
