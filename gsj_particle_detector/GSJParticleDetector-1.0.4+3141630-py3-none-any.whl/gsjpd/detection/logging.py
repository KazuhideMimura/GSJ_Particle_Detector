import os
from logging import getLogger as _getLogger

LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO").upper()


def getLogger(name: str = None, level: int | str = None):
    if name is None:
        name = "gsj-pd.detection"
    else:
        name = f"gsj-pd.detection.{name}"

    logger = _getLogger(name)
    logger.setLevel(level or LOG_LEVEL)

    return logger
