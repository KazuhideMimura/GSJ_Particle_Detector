import os
import re
from logging import INFO, Logger
from pathlib import Path
from uuid import UUID, uuid4

from PySide6.QtCore import QDir, QSize, Qt, Signal, Slot
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSizePolicy,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from ..helper.qcontext import QContext
from ..widget.console import ConsoleWidget
from ..widget.image import ImageViewWidget
from .data import ModelMetadata
from .logging import getLogger
from .model_property import ModelPropertyForm
from .parameter_set import ParameterSetForm
from .training_args import TrainingArgsForm
from .worker import TrainingThread


class ModelTrainingWidget(QWidget):
    trainCompleted = Signal(str)

    metadata: ModelMetadata = None
    logger: Logger = None

    thread: TrainingThread = None

    def __init__(self, metadata: ModelMetadata, logger: Logger, parent=None):
        super().__init__(parent)

        self.metadata = metadata
        self.logger = logger

        self.setMinimumWidth(400)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Maximum)

        with QContext(QVBoxLayout()) as layout:
            layout.setContentsMargins(3, 3, 3, 3)
            layout.setSpacing(2)
            self.setLayout(layout)

        with QContext(ModelPropertyForm(self)) as property:
            self.layout().addWidget(property)
            property.setValues(self.metadata.property)
            property.update.connect(self.onUpdateProperty)
            self.property = property

        self.layout().addSpacing(3)

        with QContext(ParameterSetForm(self)) as parameter:
            self.layout().addWidget(parameter)
            parameter.setValues(self.metadata.parameter)
            parameter.update.connect(self.onUpdateParameter)
            self.parameter = parameter

        with QContext(QFormLayout()) as layout:
            layout.setContentsMargins(3, 3, 3, 3)
            layout.setSpacing(2)
            self.layout().addLayout(layout)

            with QContext(QLabel(parent=self), QPushButton(parent=self)) as (label, button):
                label.setProperty("style", "property")
                button.setProperty("style", "primary")
                button.setText(self.tr("Write parameter file"))
                layout.addRow(label, button)

        self.layout().addSpacing(3)

        with QContext(TrainingArgsForm(self)) as train_args:
            self.layout().addWidget(train_args)
            train_args.update.connect(self.onUpdateTrainArgs)
            self.train_args = train_args

        with QContext(QFormLayout()) as layout:
            layout.setContentsMargins(3, 3, 3, 3)
            layout.setSpacing(2)
            self.layout().addLayout(layout)

            with QContext(QLabel(parent=self), QPushButton(parent=self)) as (label, button):
                label.setProperty("style", "property")
                button.setProperty("style", "primary")
                button.setText(self.tr("Train and test"))
                button.clicked.connect(self.onClickedTrain)
                layout.addRow(label, button)

            with QContext(QLabel(parent=self), QPushButton(parent=self)) as (label, button):
                label.setProperty("style", "property")
                button.setProperty("style", "primary")
                button.setText(self.tr("Test only"))
                layout.addRow(label, button)

        self.layout().addSpacing(6)
        self.layout().addStretch()

    @Slot(str, object)
    def onUpdateProperty(self, key: str, value: object):
        if hasattr(self.metadata.train_args, key):
            setattr(self.metadata.train_args, key, value)

    @Slot(str, object)
    def onUpdateParameter(self, key: str, value: object):
        # 'class#'の正規表現に一致する場合は、#を取り出してkeyとしてdictに格納する
        m = re.match(r"class(\d+)", key)
        if m:
            index = int(m.group(1))
            self.metadata.parameter.classes[index] = value
        else:
            if hasattr(self.metadata.parameter, key):
                setattr(self.metadata.parameter, key, value)

    @Slot(str, object)
    def onUpdateTrainArgs(self, key: str, value: object):
        if hasattr(self.metadata.train_args, key):
            setattr(self.metadata.train_args, key, value)

        match key:
            case "data_yaml":
                if os.path.exists(value):
                    QApplication.instance().getSetting("data_yaml_dir", os.path.dirname(value))
            case "hyp_yaml":
                if os.path.exists(value):
                    QApplication.instance().getSetting("hyp_yaml_dir", os.path.dirname(value))

    @Slot()
    def onClickedTrain(self):
        if self.thread is not None:
            self.logger.error("Training process is already running")
            return

        yolov9_dir = QApplication.instance().getSetting("yolov9_dir")
        train_py = QApplication.instance().getSetting("train_py")

        if not Path(yolov9_dir).exists():
            self.logger.error(f"Yolov9 directory not found: {yolov9_dir}")
            return

        if not Path(yolov9_dir, train_py).exists():
            self.logger.error(f"Training script not found: {train_py}")
            return

        cfg = Path(self.metadata.train_args.cfg).name
        weights = cfg.replace(".yaml", ".pt").replace("-", "")
        data_yaml = Path(self.metadata.train_args.data_yaml).name
        hyp_yaml = Path(self.metadata.train_args.hyp_yaml).name

        args = {
            "--name": "gui-test",
            "--cfg": f"models/detect/{cfg}",
            "--weights": f"pretrained/{weights}",
            "--data": f"data/{data_yaml}",
            "--hyp": f"hyps/{hyp_yaml}",
            "--img-size": str(self.metadata.train_args.img_size),
            "--epochs": str(self.metadata.train_args.epochs),
            "--batch-size": "2",
            "--device": "0",
            "--workers": "1",
        }

        self.thread = TrainingThread(exec=train_py, **args)

        self.thread.debug.connect(self.logger.debug)
        self.thread.info.connect(self.logger.info)
        self.thread.error.connect(self.logger.error)

        self.thread.started.connect(self.onThreadStarted)
        self.thread.finished.connect(self.onThreadFinished)
        self.thread.success.connect(self.onTrainingSuccess)
        self.thread.abort.connect(self.onTrainingAbort)
        self.thread.waiting.connect(QApplication.processEvents)

        QDir.setCurrent(yolov9_dir)
        self.thread.start()

    @Slot()
    def onThreadStarted(self):
        self.logger.info("Training process started")

    @Slot()
    def onThreadFinished(self):
        self.thread.deleteLater()
        self.thread = None
        self.logger.info("Training process finished")

    @Slot(str)
    def onTrainingSuccess(self, runs_dir: str):
        self.logger.error("Completed.")

        self.trainCompleted.emit(runs_dir)

    @Slot()
    def onTrainingAbort(self):
        self.logger.error("Aborted.")

    def is_running(self):
        return self.thread is not None and self.thread.isRunning()


class ModelDialog(QDialog):
    uuid: UUID = None
    logger: Logger = None
    metadata: ModelMetadata = None

    def __init__(self, metadata: ModelMetadata = None, parent=None):
        super().__init__(parent)

        self.uuid = uuid4()
        self.logger = getLogger(str(self.uuid))

        self.metadata = metadata if metadata is not None else ModelMetadata(uuid=self.uuid)

        flags = (
            Qt.WindowMinimizeButtonHint | Qt.WindowMaximizeButtonHint
        ) & ~Qt.WindowContextHelpButtonHint

        self.setWindowFlags(self.windowFlags() | flags)

        self.setMinimumSize(QSize(1280, 768))
        self.setWindowTitle(self.tr("Train detection model"))

        with QContext(QHBoxLayout()) as layout:
            layout.setContentsMargins(3, 3, 3, 3)
            self.setLayout(layout)

        with QContext(ModelTrainingWidget(self.metadata, self.logger, self)) as control:
            control.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Expanding)
            control.trainCompleted.connect(self.onTrainCompleted)
            self.layout().addWidget(control)
            self.control = control

        with QContext(QTabWidget(self)) as tab:
            tab.setObjectName("MainTabWidget")
            tab.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            self.layout().addWidget(tab)
            self.tab = tab

            with QContext(ConsoleWidget(self.logger, logLevel=INFO)) as console:
                console.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
                self.tab.addTab(console, self.tr("Log"))
                self.console = console

            with QContext(ImageViewWidget()) as label:
                label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
                label.setProperty("filename", "results.png")
                self.tab.addTab(label, self.tr("Results"))
                self.results = label

            with QContext(ImageViewWidget()) as label:
                label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
                label.setProperty("filename", "confusion_matrix.png")
                self.tab.addTab(label, self.tr("Matrix"))
                self.matrix = label

            with QContext(ImageViewWidget()) as label:
                label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
                label.setProperty("filename", "labels.jpg")
                self.tab.addTab(label, self.tr("Labels"))
                self.labels = label

            with QContext(ImageViewWidget()) as label:
                label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
                label.setProperty("filename", "labels_correlogram.jpg")
                self.tab.addTab(label, self.tr("Correlogram"))
                self.correlogram = label

        if not self.control.is_running():
            self.updateResults()

    @Slot(str)
    def onTrainCompleted(self, runs_dir: str):
        self.logger.info(f"Train completed: {runs_dir}")

        if Path(runs_dir).exists():
            self.metadata.runs_dir = runs_dir
            self.updateResults()

            # consoleのテキストを"train.log"に保存
            train_log = Path(runs_dir, "train.log")
            with open(train_log, "w", encoding="utf-8") as f:
                f.write(self.console.text())

    def updateResults(self):
        """トレーニング結果をタブに表示する"""

        if not Path(self.metadata.runs_dir).exists():
            return

        train_log = Path(self.metadata.runs_dir, "train.log")
        if train_log.exists():
            with open(train_log, "r", encoding="utf-8") as f:
                self.console.setText(f.read())

        self.updateImage(self.results)
        self.updateImage(self.matrix)
        self.updateImage(self.labels)
        self.updateImage(self.correlogram)

    def updateImage(self, widget: ImageViewWidget):
        """タブ内のQLabelに画像を表示する

        Args:
            filename (Path): runs_dirからの相対パス
            label (QLabel): 表示先のQLabel
        """
        path = Path(self.metadata.runs_dir, widget.property("filename"))
        if path.exists():
            pixmap = QPixmap(os.fspath(path))
            widget.setPixmap(pixmap)
