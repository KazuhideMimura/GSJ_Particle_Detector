import os
from pathlib import Path

from PySide6.QtCore import Signal, Slot
from PySide6.QtGui import QIntValidator
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QFormLayout,
    QGroupBox,
    QLabel,
    QLineEdit,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from ..helper.qcontext import QContext
from ..widget.filesystem import FileInputWidget
from .data import TrainingArgs


class ModelComboBox(QComboBox):
    itemSelected = Signal(str)

    def __init__(self, dir: os.PathLike = None, parent=None):
        super().__init__(parent)

        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Maximum)

        if dir is not None:
            self.setDirectory(dir)

        self.currentIndexChanged.connect(self.onCurrentIndexChanged)

    @Slot(int)
    def onCurrentIndexChanged(self, index: int):
        self.itemSelected.emit(self.currentData())

    def setDirectory(self, dir: os.PathLike):
        self.glob(dir)

    def setCurrentData(self, data: str):
        index = self.findData(data)
        if index >= 0:
            self.setCurrentIndex(index)

    def glob(self, dir: os.PathLike, pattern: str = "yolov9-?.yaml"):
        self.clear()
        if not os.path.exists(dir):
            return

        for path in Path(dir).glob(pattern):
            self.addItem(path.stem, os.fspath(path))


class TrainingArgsForm(QWidget):
    update = Signal(str, object)

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Maximum)

        with QContext(QVBoxLayout()) as layout:
            layout.setContentsMargins(3, 6, 3, 3)
            layout.setSpacing(2)
            self.setLayout(layout)

        with QContext(QGroupBox(self.tr("Train / Validation"), self)) as box:
            box.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Maximum)
            self.layout().addWidget(box)

            with QContext(QFormLayout()) as layout:
                layout.setContentsMargins(3, 3, 3, 3)
                layout.setSpacing(1)
                box.setLayout(layout)

            # --data
            with QContext(QLabel(parent=self), FileInputWidget(parent=self)) as (label, file):
                label.setText("data yaml")
                label.setProperty("style", "property")
                file.setObjectName("data_yaml")
                file.setPlaceholderText("path to dataset.yaml")
                file.setNameFilter("YAML files (*.yaml);;All files (*.*)")
                file.setInitialDir(QApplication.instance().getSetting("data_yaml_dir"))
                file.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, file)
                self.data_yaml = file

            # --hyp
            with QContext(QLabel(parent=self), FileInputWidget(parent=self)) as (label, file):
                label.setText("hyperparam yaml")
                label.setProperty("style", "property")
                file.setObjectName("hyp_yaml")
                file.setPlaceholderText("hyperparameters path")
                file.setNameFilter("YAML files (*.yaml);;All files (*.*)")
                file.setInitialDir(QApplication.instance().getSetting("hyp_yaml_dir"))
                file.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, file)
                self.hyp_yaml = file

            # --img-size
            with QContext(QLabel(parent=self), QLineEdit(parent=self)) as (label, edit):
                label.setText("img size")
                label.setProperty("style", "property")
                edit.setObjectName("img_size")
                edit.setPlaceholderText("train, val image size (pixels)")
                edit.setValidator(QIntValidator(1, 4096))
                edit.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, edit)
                self.img_size = edit

            # --cfg
            with QContext(QLabel(parent=self), ModelComboBox(parent=self)) as (label, select):
                label.setText("model size")
                label.setProperty("style", "property")
                select.setObjectName("cfg")
                # select.glob(QSettings().value("pretrained_dir"))
                select.setDirectory(
                    "D:\\YATSUO\\Workspace\\AIST-GSJ-ParticleDetector\\share\\yolov9\\models\\detect"
                )
                select.itemSelected.connect(self.onItemSelected)
                box.layout().addRow(label, select)
                self.cfg = select

            # --epochs
            with QContext(QLabel(parent=self), QLineEdit(parent=self)) as (label, edit):
                label.setText("epoch")
                label.setProperty("style", "property")
                edit.setObjectName("epochs")
                edit.setPlaceholderText("total training epochs")
                edit.setValidator(QIntValidator(1, 9999))
                edit.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, edit)
                self.epochs = edit

    @Slot()
    def onTextChanged(self):
        sender = self.sender()
        if sender is None:
            return

        if isinstance(sender.validator(), QIntValidator):
            if sender.hasAcceptableInput():
                self.update.emit(sender.objectName(), int(sender.text()))
        else:
            self.update.emit(sender.objectName(), sender.text())

    @Slot(str)
    def onItemSelected(self, text: str):
        self.update.emit(self.sender().objectName(), text)

    def setValues(self, args: TrainingArgs):
        self.data_yaml.setPath(args.data_yaml)
        self.hyp_yaml.setPath(args.hyp_yaml)
        self.img_size.setText(str(args.img_size))
        self.cfg.setCurrentData(args.cfg)
        self.epochs.setText(str(args.epochs))
