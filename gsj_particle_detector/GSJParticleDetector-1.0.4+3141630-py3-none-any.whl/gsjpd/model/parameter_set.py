from PySide6.QtCore import Signal, Slot
from PySide6.QtGui import QDoubleValidator
from PySide6.QtWidgets import (
    QFormLayout,
    QGroupBox,
    QLabel,
    QLineEdit,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from ..helper.qcontext import QContext
from ..widget.filesystem import FolderInputWidget
from .data import ParameterSet


class ParameterSetForm(QWidget):
    update = Signal(str, object)

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Maximum)

        with QContext(QVBoxLayout()) as layout:
            layout.setContentsMargins(3, 6, 3, 3)
            layout.setSpacing(2)
            self.setLayout(layout)

        with QContext(QGroupBox(self.tr("Parameter set"), self)) as box:
            box.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Maximum)
            self.layout().addWidget(box)

            with QContext(QFormLayout()) as layout:
                layout.setContentsMargins(3, 3, 3, 3)
                layout.setSpacing(1)
                box.setLayout(layout)

            with QContext(QLabel(parent=self), FolderInputWidget(parent=self)) as (label, edit):
                label.setText("path to dataset")
                label.setProperty("style", "property")
                edit.setObjectName("dataset_dir")
                edit.setPlaceholderText("path to dataset directory")
                edit.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, edit)
                self.dataset_dir = edit

            with QContext(QLabel(parent=self), QLineEdit(parent=self)) as (label, edit):
                label.setText("names")
                label.setProperty("style", "property")
                edit.setObjectName("class0")
                edit.setPlaceholderText("name of class 0")
                edit.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, edit)
                self.class0 = edit

            with QContext(QLabel(parent=self), QLineEdit(parent=self)) as (label, edit):
                label.setProperty("style", "property")
                edit.setObjectName("class1")
                edit.setPlaceholderText("name of class 1")
                edit.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, edit)
                self.class1 = edit

            with QContext(QLabel(parent=self), QLineEdit(parent=self)) as (label, edit):
                label.setProperty("style", "property")
                edit.setObjectName("class2")
                edit.setPlaceholderText("name of class 2")
                edit.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, edit)
                self.class2 = edit

            with QContext(QLabel(parent=self), QLineEdit(parent=self)) as (label, edit):
                label.setProperty("style", "property")
                edit.setObjectName("class3")
                edit.setPlaceholderText("name of class 3")
                box.layout().addRow(label, edit)
                self.class3 = edit

            with QContext(QLabel(parent=self), QLineEdit(parent=self)) as (label, edit):
                label.setProperty("style", "property")
                edit.setObjectName("class4")
                edit.setPlaceholderText("name of class 4")
                box.layout().addRow(label, edit)
                self.class4 = edit

            with QContext(QLabel(parent=self), QLineEdit(parent=self)) as (label, edit):
                label.setProperty("style", "property")
                edit.setObjectName("class5")
                edit.setPlaceholderText("name of class 5")
                edit.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, edit)
                self.class5 = edit

            with QContext(QLabel(parent=self), QLineEdit(parent=self)) as (label, edit):
                label.setProperty("style", "property")
                edit.setObjectName("class6")
                edit.setPlaceholderText("name of class 6")
                edit.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, edit)
                self.class6 = edit

            with QContext(QLabel(parent=self), QLineEdit(parent=self)) as (label, edit):
                label.setProperty("style", "property")
                edit.setObjectName("class7")
                edit.setPlaceholderText("name of class 7")
                edit.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, edit)
                self.class7 = edit

            with QContext(QLabel(parent=self), QLineEdit(parent=self)) as (label, edit):
                label.setProperty("style", "property")
                edit.setObjectName("class8")
                edit.setPlaceholderText("name of class 8")
                edit.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, edit)
                self.class8 = edit

            with QContext(QLabel(parent=self), QLineEdit(parent=self)) as (label, edit):
                label.setProperty("style", "property")
                edit.setObjectName("class9")
                edit.setPlaceholderText("name of class 9")
                edit.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, edit)
                self.class9 = edit

            with QContext(QLabel(parent=self), QLineEdit(parent=self)) as (label, edit):
                label.setText("lr0")
                label.setProperty("style", "property")
                edit.setObjectName("lr0")
                edit.setPlaceholderText("initial learning rate")
                edit.setValidator(QDoubleValidator(0, 1.0, 6))
                edit.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, edit)
                self.lr0 = edit

            with QContext(QLabel(parent=self), QLineEdit(parent=self)) as (label, edit):
                label.setText("flppud")
                label.setProperty("style", "property")
                edit.setObjectName("flppud")
                edit.setPlaceholderText("randomly flip upside down")
                edit.setValidator(QDoubleValidator(0, 1.0, 2))
                edit.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, edit)
                self.flppud = edit

            with QContext(QLabel(parent=self), QLineEdit(parent=self)) as (label, edit):
                label.setText("flpplr")
                label.setProperty("style", "property")
                edit.setObjectName("flpplr")
                edit.setPlaceholderText("randomly flip left/right")
                edit.setValidator(QDoubleValidator(0, 1.0, 2))
                edit.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, edit)
                self.flpplr = edit

    @Slot()
    def onTextChanged(self):
        sender = self.sender()
        if sender is None:
            return

        if isinstance(sender.validator(), QDoubleValidator):
            if sender.hasAcceptableInput():
                self.update.emit(sender.objectName(), float(sender.text()))
        else:
            self.update.emit(sender.objectName(), sender.text())

    def setValues(self, data: ParameterSet):
        self.dataset_dir.setText(data.dataset_dir)
        self.class0.setText(data.classes.get(0, ""))
        self.class1.setText(data.classes.get(1, ""))
        self.class2.setText(data.classes.get(2, ""))
        self.class3.setText(data.classes.get(3, ""))
        self.class4.setText(data.classes.get(4, ""))
        self.class5.setText(data.classes.get(5, ""))
        self.class6.setText(data.classes.get(6, ""))
        self.class7.setText(data.classes.get(7, ""))
        self.class8.setText(data.classes.get(8, ""))
        self.class9.setText(data.classes.get(9, ""))
        self.lr0.setText(str(data.lr0))
        self.flppud.setText(str(data.flppud))
        self.flpplr.setText(str(data.flpplr))
