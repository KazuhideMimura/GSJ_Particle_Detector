from PySide6.QtCore import Signal, Slot
from PySide6.QtWidgets import (
    QFormLayout,
    QGroupBox,
    QLabel,
    QLineEdit,
    QSizePolicy,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from ..helper.qcontext import QContext
from .data import ModelProperty


class ModelPropertyForm(QWidget):
    update = Signal(str, object)

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Maximum)

        with QContext(QVBoxLayout()) as layout:
            layout.setContentsMargins(3, 6, 3, 3)
            layout.setSpacing(2)
            self.setLayout(layout)

        with QContext(QGroupBox(self.tr("Model metadata"), self)) as box:
            box.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Maximum)
            self.layout().addWidget(box)

            with QContext(QFormLayout()) as layout:
                layout.setContentsMargins(3, 3, 3, 3)
                layout.setSpacing(1)
                box.setLayout(layout)

            # --name
            with QContext(QLabel(parent=self), QLineEdit(parent=self)) as (label, edit):
                label.setText("model name")
                label.setProperty("style", "property")
                edit.setObjectName("name")
                edit.setPlaceholderText("save to project/name")
                edit.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, edit)
                self.name = edit

            # memo
            with QContext(QLabel(parent=self), QTextEdit(parent=self)) as (label, edit):
                label.setText("memo")
                label.setProperty("style", "property")
                edit.setObjectName("memo")
                edit.setPlaceholderText("memo")
                edit.setFixedHeight(64)
                edit.textChanged.connect(self.onTextChanged)
                box.layout().addRow(label, edit)
                self.memo = edit

    @Slot()
    def onTextChanged(self):
        sender = self.sender()
        if sender is None:
            return

        if isinstance(sender, QTextEdit):
            self.update.emit(sender.objectName(), sender.toPlainText())
        else:
            self.update.emit(sender.objectName(), sender.text())

    def setValues(self, property: ModelProperty):
        self.name.setText(property.name)
        self.memo.setText(property.memo)
