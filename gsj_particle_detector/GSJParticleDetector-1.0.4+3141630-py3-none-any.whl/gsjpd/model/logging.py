import os
from logging import getLogger as _getLogger

LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO").upper()


def getLogger(name: str = None, level: int | str = None):
    if name is None:
        name = "gsj-pd.training"
    else:
        name = f"gsj-pd.training.{name}"

    logger = _getLogger(name)
    logger.setLevel(level or LOG_LEVEL)

    return logger
